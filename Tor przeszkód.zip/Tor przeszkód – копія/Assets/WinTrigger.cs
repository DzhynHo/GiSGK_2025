using UnityEngine;
using UnityEngine.UI; // Если используешь Text
// using TMPro; // Если TextMeshPro

public class WinTrigger : MonoBehaviour
{
    public GameObject winText; // Твой UI текст

    private void OnTriggerEnter(Collider other)
    {
        // Проверяем, что это игрок
        if (other.CompareTag("Player"))
        {
            winText.SetActive(true); // Показываем надпись
        }
    }
}
