using UnityEngine;

public class RespawnPlayer : MonoBehaviour
{
    public Transform respawnPoint; // точка, куда возвращать игрока

    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("Player")) // проверка, что это игрок
        {
            other.transform.position = respawnPoint.position; // возвращаем игрока
            Rigidbody rb = other.GetComponent<Rigidbody>();
            if(rb != null)
            {
                rb.linearVelocity = Vector3.zero; // сброс скорости, чтобы не “летел” дальше
            }
        }
    }
}
